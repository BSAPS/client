// 메인 페이지 컴포넌트
import Component from "../cctv-monitoring-system"

export default function Page() {
  return <Component />
}
